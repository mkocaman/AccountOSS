import React, { useState } from 'react';
import { PageContainer, ProCard } from '@ant-design/pro-components';
import { Button, Space, Typography, Alert, Tag, Divider } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined, LoadingOutlined } from '@ant-design/icons';
import client from '../../utils/client';

const { Text, Title } = Typography;

/**
 * API bağlantı test sayfası
 * Backend'in çalışıp çalışmadığını kontrol eder
 */
export const ApiTestPage: React.FC = () => {
  const [testResults, setTestResults] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  const testEndpoint = async (name: string, endpoint: string) => {
    setLoading(prev => ({ ...prev, [name]: true }));
    
    try {
      const response = await client.get(endpoint);
      setTestResults(prev => ({
        ...prev,
        [name]: { success: true, data: response.data, status: response.status }
      }));
    } catch (error: any) {
      setTestResults(prev => ({
        ...prev,
        [name]: { 
          success: false, 
          error: error.message,
          status: error.response?.status
        }
      }));
    } finally {
      setLoading(prev => ({ ...prev, [name]: false }));
    }
  };

  const endpoints = [
    { name: 'Health Check', path: '/health' },
    { name: 'Languages', path: '/settings/languages' },
    { name: 'Partners', path: '/partners?pageSize=5' },
    { name: 'Products', path: '/products?pageSize=5' },
    { name: 'Invoices', path: '/invoices?pageSize=5' }
  ];

  return (
    <PageContainer
      header={{
        title: 'API Bağlantı Testi',
        breadcrumb: {
          items: [
            { title: 'Ana Sayfa', path: '/' },
            { title: 'API Test' }
          ]
        }
      }}
    >
      <ProCard>
        <Alert
          message="Backend Bağlantı Kontrolü"
          description={
            <>
              <div>API URL: <Text code>{import.meta.env.VITE_API_URL}</Text></div>
              <div>Mock API: <Text code>{import.meta.env.VITE_USE_MOCK_API || 'false'}</Text></div>
            </>
          }
          type="info"
          style={{ marginBottom: 24 }}
        />

        <Space direction="vertical" style={{ width: '100%' }} size="large">
          {endpoints.map(({ name, path }) => (
            <ProCard key={name} size="small">
              <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                <div>
                  <Title level={5} style={{ margin: 0 }}>
                    {name}
                  </Title>
                  <Text type="secondary" code>{path}</Text>
                </div>

                <Space>
                  {loading[name] ? (
                    <Tag icon={<LoadingOutlined />} color="processing">
                      Test ediliyor...
                    </Tag>
                  ) : testResults[name] ? (
                    testResults[name].success ? (
                      <Tag icon={<CheckCircleOutlined />} color="success">
                        Başarılı ({testResults[name].status})
                      </Tag>
                    ) : (
                      <Tag icon={<CloseCircleOutlined />} color="error">
                        Hata ({testResults[name].status || 'N/A'})
                      </Tag>
                    )
                  ) : null}

                  <Button
                    type="primary"
                    size="small"
                    loading={loading[name]}
                    onClick={() => testEndpoint(name, path)}
                  >
                    Test Et
                  </Button>
                </Space>
              </Space>

              {testResults[name] && (
                <>
                  <Divider style={{ margin: '12px 0' }} />
                  <div style={{ fontSize: 12 }}>
                    <pre style={{ 
                      background: '#f5f5f5', 
                      padding: 12, 
                      borderRadius: 4,
                      overflow: 'auto',
                      maxHeight: 200
                    }}>
                      {JSON.stringify(
                        testResults[name].success ? testResults[name].data : testResults[name].error,
                        null,
                        2
                      )}
                    </pre>
                  </div>
                </>
              )}
            </ProCard>
          ))}
        </Space>

        <Divider />

        <Button
          type="primary"
          block
          onClick={() => {
            endpoints.forEach(({ name, path }) => {
              testEndpoint(name, path);
            });
          }}
        >
          Tüm Endpoint'leri Test Et
        </Button>
      </ProCard>
    </PageContainer>
  );
};
